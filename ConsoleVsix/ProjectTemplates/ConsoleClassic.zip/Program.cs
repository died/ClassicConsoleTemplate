﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace $safeprojectname$
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Hello Classic Template!");
        }
    }
}
